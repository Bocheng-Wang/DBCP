// Swiper Class
import Swiper from './components/core/core-class';

//IMPORT_COMPONENTS

const components = [
  //INSTALL_COMPONENTS
];

Swiper.use(components);

//EXPORT
